import { S3Client, PutObjectCommand, DeleteObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from "@aws-sdk/s3-request-presigner"

export class AwsService {

    state = {
        s3: undefined,    
        S3_AWS_BUCKET_NAME: "bpro-notifications",
        S3_AWS_BUCKET_REGION: "us-east-1",
        S3_AWS_BUCKET_ACCESS_KEY_ID: "AKIATQ2RKZNFBDTO464C",
        S3_AWS_BUCKET_SECRET_KEY: "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",
    }

    constructor() {
        this.state.s3 = new S3Client({
            region: this.state.S3_AWS_BUCKET_REGION,
            credentials: {
                accessKeyId: this.state.S3_AWS_BUCKET_ACCESS_KEY_ID,
                secretAccessKey: this.state.S3_AWS_BUCKET_SECRET_KEY
            }
        })
    }

    async getFromAWSCloudS3(id) {
        return new Promise(async (resolve, reject) => {
            try {
                const params = {
                    Bucket: this.state.S3_AWS_BUCKET_NAME,
                    Key: id
                };
                const command = new GetObjectCommand(params);
                const url = await getSignedUrl(this.state.s3, command);
                return resolve(url);
            } catch (err) {
                return reject(err);
            }
        })
    }

    async uploadToAWSCloudS3(file) {
        return new Promise(async (resolve, reject) => {
            try {
                const params = {
                    Bucket: this.state.S3_AWS_BUCKET_NAME,
                    Body: file.buffer,
                    Key: file.originalname
                }
                const command = new PutObjectCommand(params);
                const send = await this.state.s3.send(command);
                return resolve(send);
            } catch (err) {
                return reject(err);
            }
        })
    }

    async removeFromAWSCloudS3(id) {
        return new Promise(async (resolve, reject) => {
            try {
                const params = {
                    Bucket: this.state.S3_AWS_BUCKET_NAME,
                    Key: id
                };
                const command = new DeleteObjectCommand(params);
                const send = await this.state.s3.send(command);
                return resolve(send);
            } catch (err) {
                return reject(err);
            }
        })
    }

}

export default new AwsService();