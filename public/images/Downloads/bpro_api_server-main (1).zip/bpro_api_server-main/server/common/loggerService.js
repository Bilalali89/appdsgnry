import pino from "pino";
export default pino({
  name: 'bpro-server',
  level: 'debug',
});
