import { withConnection } from "./../../../common/database.js";
import AwsService from "../../../services/aws.service.js";

export class NotificationService {

  constructor() { }

  getNotifications() {
    return new Promise(async (resolve, reject) => {
      try {
        const connection = await withConnection();

        if (!connection) {
          return reject({ code: 501, message: "server connection error" });
        }

        let sql = `select * from notification`;

        connection.query(sql, async (err, result) => {
          if (err) return reject(err);
          let data = result;
          for (let request of data) {
            let obj = request;
            if (obj?.image_source) {
              const url = await AwsService.getFromAWSCloudS3(obj.image_source);
              obj.imageUrl = url
            }
          }
          return resolve(data);
        })

      } catch (err) {
        return reject(err);
      }
    })
  }

  saveNotification(file, body) {
    return new Promise(async (resolve, reject) => {
      try {

        const connection = await withConnection();

        if (!connection) {
          return reject({ code: 501, message: "server connection error" });
        }

        if (!file) {
          return reject({ code: 501, message: "server returned error" });
        }

        await AwsService.uploadToAWSCloudS3(file);

        if (!body) {
          return reject({ code: 501, message: "server returned error" });
        }

        const type = String(file.originalname).match(/.\w+$/g)[0].replace(".", "")
        let sql = `insert into notification (title, image_source, type) values ('${body.title}', '${file.originalname}', '${type}')`;

        connection.query(sql, (err, result) => {
          if (err) return reject(err);
          return resolve(result);
        })

      } catch (err) {
        return reject(err);
      }
    })
  }

}

export default new NotificationService();
