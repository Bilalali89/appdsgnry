import express from "express";
import { uploadMiddleware } from "../../../middlewares/file-upload.js";
import controller from "./files.controller.js";

const router = express.Router();

router.get('/', controller.getList);
router.get('/filter', controller.filterFilesList);
router.get('/last_excel_files', controller.listlastFiles);
router.delete('/last_excel_files/:id', controller.deleteLastFile);
router.post('/', uploadMiddleware().single('file'), controller.uploadFile);

export default router;