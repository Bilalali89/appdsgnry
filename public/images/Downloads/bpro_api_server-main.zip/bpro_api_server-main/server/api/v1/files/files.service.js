import rimraf from "rimraf";
import { withConnection } from "./../../../common/database.js";
import XLSX from "xlsx";
import { v4 as uuidv4 } from "uuid";
export class FilesService {
  constructor() { }
  async getList(country) {
    return new Promise(async (resolve, reject) => {
      try {
        const connection = await withConnection();
        if (!connection) {
          return reject({ code: 501, message: "server connection error" });
        }
        let query = '';
        if(!country) {
          query = 'SELECT e.id, e.IPC, e.OEM ,e.Model ,e.Size ,e.LISS ,e.PATTERN ,e.AXLE ,e.MARKINGS ,e.TECHNOLOGIES, e.SHARE, pid.uuid FROM egypt e INNER JOIN product_uuid pid on e.PATTERN = pid.PATTERN ';
        } else {
          query = `SELECT e.id, e.IPC, e.OEM ,e.Model ,e.Size ,e.LISS ,e.PATTERN ,e.AXLE ,e.MARKINGS ,e.TECHNOLOGIES, e.SHARE, pid.uuid FROM egypt e INNER JOIN product_uuid pid on e.PATTERN = pid.PATTERN where e.COUNTRY = '${country}'`;
        }
        connection.query(query, function (err, result, fields) {
          if (err) return reject(err);
          return resolve(result);
        });
      } catch (err) {
        return reject(err);
      }
    })
  }
  async filterFiles(
    filter
  ) {
    return new Promise(async (resolve, reject) => {
      try {
        const connection = await withConnection();
        if (!connection) {
          return reject({ code: 501, message: "server connection error" });
        }
        let query = '';
        if(!filter) {
          query = 'SELECT * FROM egypt';
        } else {
          query = `SELECT * FROM egypt where OEM='${filter}'`;
        }
        connection.query(query, function (err, result, fields) {
          if (err) return reject(err);
          return resolve(result);
        });
      } catch (err) {
        return reject(err);
      }
    })
  }
  async uploadFile(file, country) {
    return new Promise(async (resolve, reject) => {
      try {
        const connection = await withConnection();
        if (!connection) {
          return reject({ code: 501, message: "server connection error" });
        }
        if (!country) {
          return reject({ code: 400, message: "Country not found, please provide a registered country." });
        }
        let fileSql = `insert into last_excel_file (id, name, size, type) values ('${uuidv4()}', '${file.originalname}', '${file.size}', '${file.mimetype}')`;
        connection.query(fileSql, (err, result) => {
          if (err) return reject(err);
        })
        let workbook = XLSX.readFile(`uploads/${file.filename}`);
        let sheet_name_list = workbook.SheetNames;
        let xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
        rimraf('uploads/*', function () { });
        xlData.forEach((data) => {
          let sql = `insert into egypt (id, IPC, OEM, Model, Size, LISS, PATTERN, AXLE, MARKINGS, TECHNOLOGIES, SHARE, COUNTRY) values ('${uuidv4()}', '${data.IPC}', '${data.OEM}', '${data.Model}', '${data.Size}', '${data.LISS}', '${data.PATTERN}', '${data.AXLE}', '${data.MARKINGS}', '${data.TECHNOLOGIES}', '${data.SHARE}', '${country}')`;
          connection.query(sql, (err, result) => {
            if (err) return reject(err);
          })
        });
        return resolve({ code: 200, message: "Data inserted successfully" })
      } catch (err) {
        return reject(err);
      }
    })
  }
  async listlastFiles(
  ) {
    return new Promise(async (resolve, reject) => {
      try {
        const connection = await withConnection();
        if (!connection) {
          return reject({ code: 501, message: "server connection error" });
        }
        connection.query('SELECT * FROM last_excel_file', function (err, result) {
          if (err) return reject(err);
          return resolve(result);
        });
      } catch (err) {
        return reject(err);
      }
    })
  }
  async deleteLastFile(id) {
    return new Promise(async (resolve, reject) => {
      try {
        const connection = await withConnection();
        if (!connection) {
          return reject({ code: 501, message: "server connection error" });
        }
        connection.query(`DELETE FROM last_excel_file WHERE id='${id}'`, function (err, result) {
          if (err) return reject(err);
          return resolve(result);
        });
      } catch (err) {
        return reject(err);
      }
    })
  }
}
export default new FilesService();
