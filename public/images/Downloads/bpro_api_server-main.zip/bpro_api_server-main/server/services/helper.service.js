import path from "path";
import { v4 as uuidv4 } from 'uuid';

export class HelperService {

    handleFileDetails(file) {
        let requestedFile = file;
        const filename = path.parse(file.originalname).name.replace(/\s/g, '') + uuidv4();
        const extension = path.parse(file.originalname).ext;
        requestedFile.originalname = `${filename}${extension}`;
        return requestedFile;
    }

}

export default new HelperService();